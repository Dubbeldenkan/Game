#include <d3dx9.h>

#ifndef IMAGE_H
#define IMAGE_H

class Image
{
public:
	LPDIRECT3DTEXTURE9 _texture;

	Image() {};
};

#endif // !IMAGE_H
