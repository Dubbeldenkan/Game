#include <d3d9.h>
#include <Windows.h>
#include "Image.h"
#include <stdio.h>
#include <D3dx9math.h>

#ifndef GRAPHICS_H
#define GRAPHICS

class Graphics
{
	LPDIRECT3D9 _d3d;
	LPDIRECT3DDEVICE9 _d3dDevice;
	LPD3DXSPRITE _sprite = 0;
public:
	Graphics(HWND hWnd);
	~Graphics();

	void Flip(bool waitRetrace = true); 

	void Clear(DWORD color = 0);

	Image LoadImage(const char* filename);

	void Draw(Image image, int x, int y, float scale);
};

#endif